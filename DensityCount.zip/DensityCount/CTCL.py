import argparse
import re
from typing import Dict, List, Tuple, Any
import pandas as pd

# ---------------------- Configuration ----------------------

SCHEMAS: Dict[str, Dict[str, List[str]]] = {
    "CTCL": {
        "specific": [
            r"(Pautrier(?:微)?脓肿)",                    # Pautrier 微脓肿
            r"(TCR(?:重排)?)",                          # TCR 或 TCR 重排
            r"(克隆性|克隆扩增|基因重排)",               # 克隆学证据
            r"(CD3|CD4|CD5|CD8|CD30|CD56)",     # 免疫表型
            r"(表皮向性|表皮浸润)",                      # 表皮向性
            r"(皮肤活检|淋巴细胞浸润|淋巴细胞侵入)",      # 病理活检常见表述
        ],
        "support": [
            r"(斑片|斑块|浸润性红斑|丘疹|结节|肿块|糜烂|溃疡|鳞屑|紫红|红皮病|红斑)",  # 皮肤表现
            r"(淋巴结肿大|浅表淋巴结肿大)",             # 淋巴结受累
            r"(瘙痒|顽固性瘙痒)",                       # 瘙痒
        ],
    },
}


SPECIFIC_POINTS = 5
SUPPORT_POINTS = 1

# 默认输出路径（你的目录 + 文件名）
DEFAULT_OUTPUT_PATH = r"/Users/hongbin/Desktop/Revsion/LCH.xlsx"

# ---------------------- Helpers ----------------------

def detect_columns(df: pd.DataFrame) -> Tuple[str, str]:
    """
    Detect the first two columns as (id_col, text_col).
    """
    if df.shape[1] < 2:
        raise ValueError("Input Excel must have at least two columns: ID and TEXT.")
    id_col = df.columns[0]
    text_col = df.columns[1]
    return id_col, text_col

def normalize_text(s: Any) -> str:
    """
    Convert NaN to empty string; strip spaces; unify certain whitespace.
    """
    if pd.isna(s):
        return ""
    return str(s).replace("\u3000", " ").strip()

def compile_schema_patterns(schema: Dict[str, List[str]]) -> Dict[str, List[re.Pattern]]:
    compiled = {}
    for key in ["specific", "support"]:
        plist = schema.get(key, [])
        compiled[key] = [re.compile(p, flags=re.IGNORECASE) for p in plist]
    return compiled

def score_text_occurrences(
    text: str, compiled_patterns: Dict[str, List[re.Pattern]]
) -> Tuple[int, int, int, int, List[str], List[str]]:
    """
    Count *every occurrence* for each pattern (non-overlapping, per Python regex semantics).

    Returns:
        specific_pattern_count: number of distinct specific patterns that matched >=1 time
        support_pattern_count:  number of distinct support patterns that matched >=1 time
        specific_match_count:   total number of specific matches across all patterns
        support_match_count:    total number of support matches across all patterns
        specific_hits:          list of matched substrings (for transparency)
        support_hits:           list of matched substrings (for transparency)
    """
    specific_pattern_count = 0
    support_pattern_count = 0
    specific_match_count = 0
    support_match_count = 0
    specific_hits: List[str] = []
    support_hits: List[str] = []

    # Specific
    for pat in compiled_patterns.get("specific", []):
        found_any = False
        for m in pat.finditer(text):
            specific_match_count += 1
            specific_hits.append(m.group(0))
            found_any = True
        if found_any:
            specific_pattern_count += 1

    # Support
    for pat in compiled_patterns.get("support", []):
        found_any = False
        for m in pat.finditer(text):
            support_match_count += 1
            support_hits.append(m.group(0))
            found_any = True
        if found_any:
            support_pattern_count += 1

    return (
        specific_pattern_count,
        support_pattern_count,
        specific_match_count,
        support_match_count,
        specific_hits,
        support_hits,
    )

def compute_density(total_points: int, char_len_no_space: int, per_chars: int = 1000) -> float:
    if char_len_no_space <= 0:
        return 0.0
    return total_points / (char_len_no_space / per_chars)

# ---------------------- Main ----------------------

def run(input_path: str, output_path: str = None, sheet_name: str = None, schema_name: str = "AL") -> pd.DataFrame:
    # Read
    if sheet_name:
        df = pd.read_excel(input_path, sheet_name=sheet_name)
    else:
        df = pd.read_excel(input_path)
    id_col, text_col = detect_columns(df)

    # Prepare schema
    if schema_name not in SCHEMAS:
        raise ValueError(f"Schema '{schema_name}' not found. Available: {list(SCHEMAS.keys())}")
    compiled = compile_schema_patterns(SCHEMAS[schema_name])

    # Process
    out_rows = []
    for _, row in df.iterrows():
        rid = row[id_col]
        raw_text = row[text_col]
        text = normalize_text(raw_text)
        char_len_no_space = len("".join(text.split()))  # remove all whitespace for length

        (
            s_pat_cnt, sup_pat_cnt,
            s_match_cnt, sup_match_cnt,
            s_hits, sup_hits
        ) = score_text_occurrences(text, compiled)

        # 出现一次就记一次：按 pattern 种类计分
        s_pts = s_pat_cnt * SPECIFIC_POINTS
        sup_pts = sup_pat_cnt * SUPPORT_POINTS
        total_pts = s_pts + sup_pts
        density_per_1000_chars = compute_density(total_pts, char_len_no_space, per_chars=1000)

        out_rows.append({
            id_col: rid,
            text_col: raw_text,
            # 区分：pattern_count（命中过的不同正则数量） vs match_count（所有出现次数总和）
            f"{schema_name}_specific_pattern_count": s_pat_cnt,
            f"{schema_name}_support_pattern_count": sup_pat_cnt,
            f"{schema_name}_specific_match_count": s_match_cnt,
            f"{schema_name}_support_match_count": sup_match_cnt,
            f"{schema_name}_specific_points": s_pts,
            f"{schema_name}_support_points": sup_pts,
            f"{schema_name}_total_points": total_pts,
            f"{schema_name}_density_per_1000_chars": round(density_per_1000_chars, 4),
            f"{schema_name}_specific_hits": "; ".join(map(str, s_hits)),
            f"{schema_name}_support_hits": "; ".join(map(str, sup_hits)),
            "text_char_len_no_space": char_len_no_space,
        })

    out_df = pd.DataFrame(out_rows)
    # Keep original order: ID, TEXT, then scores
    cols = [id_col, text_col] + [c for c in out_df.columns if c not in (id_col, text_col)]
    out_df = out_df[cols]

    # Save
    save_path = output_path if output_path else DEFAULT_OUTPUT_PATH
    out_df.to_excel(save_path, index=False)
    return out_df


def main():
    parser = argparse.ArgumentParser(
        description="Compute diagnostic keyword density for CTCL schema."
    )
    parser.add_argument("--input", required=True, help="Path to input .xlsx file (first col = ID, second col = TEXT).")
    parser.add_argument("--output", default="/Users/hongbin/Desktop/Revsion/CTCL-output.xlsx", help="Path to output .xlsx file.")
    parser.add_argument("--sheet", default=None, help="Optional Excel sheet name to read from.")
    parser.add_argument("--schema", default="CTCL", help="Schema name to use (default: CTCL).")  # 👈 确认你有这一行
    args = parser.parse_args()

    run(args.input, args.output, sheet_name=args.sheet, schema_name=args.schema)


if __name__ == "__main__":
    main()
